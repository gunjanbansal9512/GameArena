
/**
  Index JS Created as model object for 
  @author : Gunjan Bansal
**/
var data;
var titlesAutoComplete = [];
const loaderHtml=`
  <div id="preloader" class="overlay">
    <div class="overlay__inner">
        <div class="overlay__content"><span class="spinner"></span></div>
    </div>
  </div>
`
//'<div id="preloader" class="text-lg-left">Loading...</div>'
$("body").prepend(loaderHtml);

$(document).ready(function() {
    data = $.getJSON("http://starlord.hackerearth.com/gamesext", function(data) {
        //  console.log(data);
        //$('#gameData').append(renderData);
        for (var i = 0; i < data.length; i++) {
            var gameObj = getCardRender(data[i]);
            $('#gameData').append(gameObj);

            titlesAutoComplete.push(data[i]['title'])
        }
         $("#preloader").remove();
    });
});

function getCardRender(gameObj) {
    const row =
        `<div class="col-sm-3" id="cards" style="margin-top:8px ">
    <div class="card card-body h-100">
        <img class="card-img-top" src="image.jpg" alt="Card image cap">
        <div>
            <h6 class="font-weight-bold text-center mt-1" id="title">Title : ${gameObj['title']} </h6>
            <div class="container">
                <div class="row text-capitalize">
                    <span class="col-12"> <span class="font-weight-bold">Platform :</span> ${gameObj['platform']} </span>
                    <span class="col-12"><span class="font-weight-bold text-sm-left">Score :</span> ${gameObj['score']}</span>
                    <span class="col-12"><span class="font-weight-bold">Genre:</span> ${gameObj['genre'] }</span>
                    <span class="col-12"><span class="font-weight-bold">Editiors Choice:</span> ${ gameObj['editors_choice'] }</span>
                    <span class="col-12"><span class="font-weight-bold">Release Year:</span> ${gameObj['release_year'] }</span>
                    <span class="col-12"><a class="card-link" href="#">URL : ${gameObj['url']} </a></span>
                </div>
            </div>
        </div>
    </div>
</div>`
    return row;
}
// Search Utilty Function  
$("#searchBtn").on("click", function() {
    $('#gameData').empty(); //clean
    var searchText = $("#search").val().trim();

    let restJsondata = data.responseJSON;
    var filteredData = [];
    for (var i = 0; i < restJsondata.length; i++) {
        var title = restJsondata[i]['title'];
        if (title) {
            if (title.toString().toLowerCase().search(searchText.toLowerCase()) == 0) {
                // console.log(restJsondata[i]);
                var gameObj = getCardRender(restJsondata[i]);
                $('#gameData').append(gameObj);
            }
        }

    }
});
// Low to high
$("#sortD").on("click", function() {
    $('#gameData').empty();
    let restJsondata = data.responseJSON;

    restJsondata.sort((a, b) => Number(a.score) - Number(b.score));
    // console.log("ascending", restJsondata);
    for (var i = 0; i < restJsondata.length; i++) {
        var gameObj = getCardRender(restJsondata[i]);
        $('#gameData').append(gameObj);
    }
});
// High to low
$("#sortA").on("click", function() {
    $('#gameData').empty();
    let restJsondata = data.responseJSON;

    restJsondata.sort((a, b) => Number(b.score) - Number(a.score));
    // console.log("desc", restJsondata);
    for (var i = 0; i < restJsondata.length; i++) {
        var gameObj = getCardRender(restJsondata[i]);
        $('#gameData').append(gameObj);
    }
});




/**
    Java Script Code Written to achieve Auto Complete feature
**/
autocomplete(document.getElementById("search"), titlesAutoComplete);

function autocomplete(inp, arr) {
  /*the autocomplete function takes two arguments,
  the text field element and an array of possible autocompleted values:*/
  var currentFocus;
  /*execute a function when someone writes in the text field:*/
  inp.addEventListener("input", function(e) {
      var a, b, i, val = this.value;
      /*close any already open lists of autocompleted values*/
      closeAllLists();
      if (!val) { return false;}
      currentFocus = -1;
      /*create a DIV element that will contain the items (values):*/
      a = document.createElement("DIV");
      a.setAttribute("id", this.id + "autocomplete-list");
      a.setAttribute("class", "autocomplete-items");
      /*append the DIV element as a child of the autocomplete container:*/
      this.parentNode.appendChild(a);
      /*for each item in the array...*/
      for (i = 0; i < arr.length; i++) {
        /*check if the item starts with the same letters as the text field value:*/
        if (arr[i].toString().substr(0, val.length).toUpperCase() == val.toUpperCase()) {
          /*create a DIV element for each matching element:*/
          b = document.createElement("DIV");
          /*make the matching letters bold:*/
          b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
          b.innerHTML += arr[i].substr(val.length);
          /*insert a input field that will hold the current array item's value:*/
          b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
          /*execute a function when someone clicks on the item value (DIV element):*/
              b.addEventListener("click", function(e) {
              /*insert the value for the autocomplete text field:*/
              inp.value = this.getElementsByTagName("input")[0].value;
              /*close the list of autocompleted values,
              (or any other open lists of autocompleted values:*/
              closeAllLists();
          });
          a.appendChild(b);
        }
      }
  });
  /*execute a function presses a key on the keyboard:*/
  inp.addEventListener("keydown", function(e) {
      var x = document.getElementById(this.id + "autocomplete-list");
      if (x) x = x.getElementsByTagName("div");
      if (e.keyCode == 40) {
        /*If the arrow DOWN key is pressed,
        increase the currentFocus variable:*/
        currentFocus++;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 38) { //up
        /*If the arrow UP key is pressed,
        decrease the currentFocus variable:*/
        currentFocus--;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 13) {
        /*If the ENTER key is pressed, prevent the form from being submitted,*/
        e.preventDefault();
        if (currentFocus > -1) {
          /*and simulate a click on the "active" item:*/
          if (x) x[currentFocus].click();
        }
      }
  });
  function addActive(x) {
    /*a function to classify an item as "active":*/
    if (!x) return false;
    /*start by removing the "active" class on all items:*/
    removeActive(x);
    if (currentFocus >= x.length) currentFocus = 0;
    if (currentFocus < 0) currentFocus = (x.length - 1);
    /*add class "autocomplete-active":*/
    x[currentFocus].classList.add("autocomplete-active");
  }
  function removeActive(x) {
    /*a function to remove the "active" class from all autocomplete items:*/
    for (var i = 0; i < x.length; i++) {
      x[i].classList.remove("autocomplete-active");
    }
  }
  function closeAllLists(elmnt) {
    /*close all autocomplete lists in the document,
    except the one passed as an argument:*/
    var x = document.getElementsByClassName("autocomplete-items");
    for (var i = 0; i < x.length; i++) {
      if (elmnt != x[i] && elmnt != inp) {
      x[i].parentNode.removeChild(x[i]);
    }
  }
}
/*execute a function when someone clicks in the document:*/
document.addEventListener("click", function (e) {
    closeAllLists(e.target);
});
}